import * as ed from '@noble/ed25519';

const b64u = {
  enc: (buf) => Buffer.from(buf).toString('base64').replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''),
  dec: (s) => Buffer.from(s.replace(/-/g,'+').replace(/_/g,'/'), 'base64')
};

export async function signLicense(payload, privateKeyHex) {
  const body = b64u.enc(Buffer.from(JSON.stringify(payload)));
  const sig = await ed.sign(new TextEncoder().encode(body), Buffer.from(privateKeyHex, 'hex'));
  return `${body}.${b64u.enc(sig)}`;
}

export async function verifyLicense(token, publicKeyHex) {
  const [body, sigB64] = token.split('.');
  if (!body || !sigB64) return { ok: false, reason: 'format' };
  const msg = new TextEncoder().encode(body);
  const sig = b64u.dec(sigB64);
  const ok = await ed.verify(sig, msg, Buffer.from(publicKeyHex, 'hex'));
  if (!ok) return { ok: false, reason: 'bad_sig' };
  const payload = JSON.parse(Buffer.from(b64u.dec(body)).toString('utf8'));
  const now = Math.floor(Date.now()/1000);
  if (payload.exp && now > payload.exp) return { ok: false, reason: 'expired', payload };
  return { ok: true, payload };
}
