import Stripe from 'stripe';
import { verifyLicense, signLicense } from './_sign.js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  try {
    const { token } = req.query;
    if (!token) return res.status(400).json({ error: 'missing_token' });

    const v = await verifyLicense(token, process.env.LIC_PUBLIC_KEY_HEX);
    if (!v.ok && v.reason !== 'expired') return res.status(401).json({ error: 'bad_token' });

    const payload = v.payload || JSON.parse(Buffer.from(token.split('.')[0].replace(/-/g,'+').replace(/_/g,'/'), 'base64').toString('utf8'));
    const customerId = payload.sub;
    if (!customerId) return res.status(400).json({ error: 'no_customer' });

    const subs = await stripe.subscriptions.list({ customer: customerId, status: 'all', limit: 3 });
    const isActive = subs.data.some(s => ['active','trialing','past_due'].includes(s.status));
    if (!isActive) return res.status(402).json({ error: 'subscription_inactive' });

    const now = Math.floor(Date.now()/1000);
    const newPayload = { ...payload, iat: now, exp: now + 30*24*3600 };
    const newToken = await signLicense(newPayload, process.env.LIC_PRIVATE_KEY_HEX);
    return res.json({ token: newToken });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'server_error' });
  }
}
