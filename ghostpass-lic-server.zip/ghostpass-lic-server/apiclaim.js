import Stripe from 'stripe';
import { signLicense } from './_sign.js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  try {
    const { session_id } = req.query;
    if (!session_id) return res.status(400).json({ error: 'missing_session_id' });

    const session = await stripe.checkout.sessions.retrieve(session_id, { expand: ['customer', 'subscription'] });
    if (!session.customer) return res.status(400).json({ error: 'no_customer' });

    let active = false, subId = null;
    if (session.subscription) {
      subId = typeof session.subscription === 'string' ? session.subscription : session.subscription.id;
      const sub = typeof session.subscription === 'string' ? await stripe.subscriptions.retrieve(subId) : session.subscription;
      active = ['trialing','active','past_due'].includes(sub.status);
    }
    if (!active) return res.status(402).json({ error: 'subscription_inactive' });

    const now = Math.floor(Date.now()/1000);
    const payload = {
      ver: 1,
      plan: 'PRO',
      sub: session.customer,
      sub_id: subId,
      iat: now,
      exp: now + 30*24*3600,
      issuer: 'ghostpass'
    };

    const token = await signLicense(payload, process.env.LIC_PRIVATE_KEY_HEX);
    return res.json({ token });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'server_error' });
  }
}
